
// Genre data with approximate game counts (used for sizing)
        const genreData = [
            { name: 'Action', count: 2956, color: '#FF6B35' },
            { name: 'Adventure', count: 910, color: '#F7931E' },
            { name: 'Fighting', count: 784, color: '#E63946' },
            { name: 'Misc', count: 1530, color: '#9B59B6' },
            { name: 'Platform', count: 832, color: '#3498DB' },
            { name: 'Puzzle', count: 483, color: '#E74C3C' },
            { name: 'Racing', count: 1117, color: '#E74C3C' },
            { name: 'Role-playing', count: 1349, color: '#E74C3C' },
            { name: 'Shooter', count: 1172, color: '#E74C3C' }, 
            { name: 'Simulation', count: 752, color: '#E74C3C' }, 
            { name: 'Sports', count: 2170, color: '#95A5A6' },
            { name: 'Strategy', count: 683, color: '#1ABC9C' }
            
        ];
        
     
        // Configuration
        const config = {
            width: 2000,
            height: 1200,
            minRadius: 95,  //Increase the min and max radius so the hexagons appear bigger. 
            maxRadius: 150,
            padding: 20
          };
 
        // Select SVG and set dimensions
        const svg = d3.select("#hexagon-container")
           .attr("viewBox", `0 0 ${config.width} ${config.height}`)
           .attr("preserveAspectRatio", "xMidYMid meet");

        // Calculate total games
const totalGames = d3.sum(genreData, d => d.count);
 
// Create scale for hexagon radius based on game count
const radiusScale = d3.scaleSqrt()
  .domain([0, d3.max(genreData, d => d.count)])
  .range([config.minRadius, config.maxRadius]);
 
// Add radius to data
genreData.forEach(d => {
  d.radius = radiusScale(d.count);
  d.percentage = ((d.count / totalGames) * 100).toFixed(1);
});
 
// Function to generate hexagon path
function createHexagonPath(radius) {
  const points = [];
  
  // Calculate 6 vertices of hexagon
  // Starting angle offset by -90 degrees to make the top flat
  for (let i = 0; i < 6; i++) {
    const angle = (Math.PI / 3) * i - (Math.PI / 2);
    const x = radius * Math.cos(angle);
    const y = radius * Math.sin(angle);
    points.push([x, y]);
  }
  
  // Create SVG path string
  // M = move to first point, L = line to next points, Z = close path
  return "M" + points.join("L") + "Z";
}
 
// Pack hexagons using force simulation to avoid overlap
const simulation = d3.forceSimulation(genreData)
  .force("x", d3.forceX(1000).strength(0.05))
  .force("y", d3.forceY(700).strength(0.15))
  .force("collide", d3.forceCollide(d => d.radius + config.padding))
  .stop();
 
// Run simulation manually
for (let i = 0; i < 300; i++) {
  simulation.tick();
}
 
// Create group for each hexagon
const hexGroups = svg.selectAll("g.hex-group")
  .data(genreData)
  .enter()
  .append("g")
  .attr("class", "hex-group")
  .attr("transform", d => `translate(${d.x}, ${d.y})`);
 
// Draw hexagons
hexGroups.append("path")
  .attr("class", "hexagon")
  .attr("d", d => createHexagonPath(d.radius)) //Call the createHexagonPath helper function. 
  .attr("fill", d => d.color)
  .on("mouseover", handleMouseOver)
  .on("mousemove", handleMouseMove)
  .on("mouseout", handleMouseOut);
 
// Add genre labels
hexGroups.append("text")
  .attr("class", "genre-label")
  .attr("dy", "0.5em")
  .attr("dx", "-0.5em")
  .attr("text-anchor", "middle")
  .style("font-family", "Orbitron", "sans-serif")
  .style("text-transform", "uppercase")
  .style("letter-spacing", "0.05em")
  .style("margin-bottom", "8px")
  .text(d => d.name);
 
// Add count labels
hexGroups.append("text")
  .attr("class", "count-label")
  .attr("dy", "1.2em")
  .attr("text-anchor", "middle")
  .style("font-family", "Orbitron", "sans-serif")
  .style("margin-top", "8px")
  .style("font-size", "clamp(1rem, 1.5vw, 1.4rem)")
  .text(d => d.count.toLocaleString());


// Tooltip element
const tooltip = d3.select("#tooltip");
 
// Event handlers
function handleMouseOver(event, d) {
  // Highlight hexagon
  d3.select(this)
    .transition()
    .duration(300)
    .attr("transform", "scale(1.05)");
  
  // Show tooltip
  tooltip.classed("visible", true)
    .html(`
      <div class="tooltip-genre">${d.genre}</div>
      <div class="tooltip-count">${d.count.toLocaleString()} games</div>
      <div class="tooltip-percentage">${d.percentage}% of total</div>
    `);
}
 
function handleMouseMove(event) {
  // Position tooltip near cursor
  tooltip
    .style("left", (event.pageX + 15) + "px")
    .style("top", (event.pageY - 15) + "px");
}
 
function handleMouseOut(event, d) {
  // Reset hexagon
  d3.select(this)
    .transition()
    .duration(200)
    .attr("transform", "scale(1)");
  
  // Hide tooltip
  tooltip.classed("visible", false);
}
 
// Add entrance animation
hexGroups
  .style("opacity", 0)
  .transition()
  .duration(800)
  .delay((d, i) => i * 50)
  .style("opacity", 1);