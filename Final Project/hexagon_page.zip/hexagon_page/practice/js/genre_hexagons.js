const genreData = [
    { genre: "Action", gameCount: 3370, color: "#ff6b3d" },
    { genre: "Sports", gameCount: 2348, color: "#f79a1f" },
    { genre: "Shooter", gameCount: 1750, color: "#9ca6af" },
    { genre: "RPG", gameCount: 1488, color: "#9b66c4" },
    { genre: "Racing", gameCount: 1323, color: "#f23b56" },
    { genre: "Platform", gameCount: 1249, color: "#ec5548" },
    { genre: "Puzzle", gameCount: 888, color: "#46a8e8" },
    { genre: "Strategy", gameCount: 683, color: "#2fc9b8" },
    { genre: "Adventure", gameCount: 610, color: "#4f7de8" },
    { genre: "Simulation", gameCount: 540, color: "#56c16a" },
    { genre: "Fighting", gameCount: 470, color: "#d16ee3" },
    { genre: "Misc", gameCount: 390, color: "#f3c84a" }
];

function scaleRadius(value, minValue, maxValue, minRadius = 24, maxRadius = 68) {
    if (minValue === maxValue) {
        return (minRadius + maxRadius) / 2;
    }

    const normalized = (value - minValue) / (maxValue - minValue);
    return minRadius + normalized * (maxRadius - minRadius);
}

function hexagonPoints(cx, cy, radius) {
    const points = [];
    for (let i = 0; i < 6; i += 1) {
        const angle = (Math.PI / 180) * (60 * i - 30);
        const x = cx + radius * Math.cos(angle);
        const y = cy + radius * Math.sin(angle);
        points.push(`${x},${y}`);
    }
    return points.join(" ");
}

function drawHexagonGroup(svg, d, cx, cy, radius) {
    const group = document.createElementNS("http://www.w3.org/2000/svg", "g");

    const polygon = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
    polygon.setAttribute("points", hexagonPoints(cx, cy, radius));
    polygon.setAttribute("fill", d.color);
    polygon.setAttribute("fill-opacity", "0.85");
    polygon.setAttribute("stroke", "#0f172a");
    polygon.setAttribute("stroke-width", "1.25");
    group.appendChild(polygon);

    const label = document.createElementNS("http://www.w3.org/2000/svg", "text");
    label.setAttribute("x", cx);
    label.setAttribute("y", cy - 8);
    label.setAttribute("class", "hex-label");
    label.textContent = d.genre;
    group.appendChild(label);

    const subLabel = document.createElementNS("http://www.w3.org/2000/svg", "text");
    subLabel.setAttribute("x", cx);
    subLabel.setAttribute("y", cy + 10);
    subLabel.setAttribute("class", "hex-sub-label");
    subLabel.textContent = `${d.gameCount} games`;
    group.appendChild(subLabel);

    svg.appendChild(group);
}

function drawSideBySideLayout(data) {
    const svg = document.getElementById("row-layout");
    const width = Number(svg.getAttribute("width"));
    const height = Number(svg.getAttribute("height"));

    const counts = data.map((d) => d.gameCount);
    const minCount = Math.min(...counts);
    const maxCount = Math.max(...counts);
    const spacing = width / (data.length + 1);

    data.forEach((d, i) => {
        const cx = spacing * (i + 1);
        const cy = height / 2;
        const radius = scaleRadius(d.gameCount, minCount, maxCount);
        drawHexagonGroup(svg, d, cx, cy, radius);
    });
}

function drawOrderedScatterLayout(data) {
    const svg = document.getElementById("random-layout");
    const width = Number(svg.getAttribute("width"));
    const height = Number(svg.getAttribute("height"));

    const counts = data.map((d) => d.gameCount);
    const minCount = Math.min(...counts);
    const maxCount = Math.max(...counts);
    // Fixed staggered order inspired by your reference image.
    // Values are percentages of the SVG width/height.
    const slots = [
        { px: 0.20, py: 0.19 },
        { px: 0.43, py: 0.19 },
        { px: 0.66, py: 0.15 },
        { px: 0.12, py: 0.46 },
        { px: 0.36, py: 0.48 },
        { px: 0.60, py: 0.46 },
        { px: 0.24, py: 0.77 },
        { px: 0.49, py: 0.77 },
        { px: 0.78, py: 0.31 },
        { px: 0.80, py: 0.60 },
        { px: 0.69, py: 0.82 },
        { px: 0.42, py: 0.90 }
    ];

    data.forEach((d, index) => {
        const radius = scaleRadius(d.gameCount, minCount, maxCount);
        const slot = slots[index % slots.length];
        const x = slot.px * width;
        const y = slot.py * height;
        drawHexagonGroup(svg, d, x, y, radius);
    });
}

drawSideBySideLayout(genreData);
drawOrderedScatterLayout(genreData);
